#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
map_name="${1:-clean_room}"
map_name="${map_name%.world}"
world_file="${script_dir}/worlds/${map_name}.world"

case "${map_name}" in
  clean_room|many_rooms|six_rooms_ob|wwss) ;;
  *)
    echo "未知地图：${map_name}" >&2
    echo "可选地图：clean_room, many_rooms, six_rooms_ob, wwss" >&2
    exit 2
    ;;
esac

if ! command -v gazebo >/dev/null 2>&1; then
  echo "未找到 gazebo 命令。请安装 Gazebo Classic 11。" >&2
  exit 127
fi

exec gazebo "${world_file}"
