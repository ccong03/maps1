# Yahboomcar 四张地图迁移包

本包包含 `clean_room`、`many_rooms`、`six_rooms_ob` 和 `wwss` 四套环境。

## 目录内容

- `worlds/*.world`：Gazebo 三维仿真世界，墙体、地面和障碍物都已直接写入文件。
- `navigation_maps/*.pgm`：ROS 导航使用的二维栅格地图图像。
- `navigation_maps/*.yaml`：与 PGM 配套的分辨率、原点和占用阈值配置。
- `open_world.sh`：在终端中快速打开指定世界的脚本。

四个 world 没有引用项目里的外部 mesh、贴图或自定义 Gazebo 插件，只使用 Gazebo 自带的 `Gazebo/Grey` 材质。因此，仅查看这四个静态环境时不需要复制整个 ROS 工作空间。

## 在另一台电脑打开

这些文件是在 Gazebo Classic 11（本机为 11.10.2）下检查的，建议目标电脑也安装 Gazebo Classic 11。

进入本文件夹后运行：

```bash
./open_world.sh clean_room
./open_world.sh many_rooms
./open_world.sh six_rooms_ob
./open_world.sh wwss
```

也可以直接运行：

```bash
gazebo worlds/clean_room.world
```

如果脚本没有执行权限，先运行：

```bash
chmod +x open_world.sh
```

## PGM/YAML 怎么用

PGM/YAML 是 ROS 导航地图，不是 Gazebo 三维模型。Gazebo 打开 `.world` 时不需要它们；启动 ROS 的 map_server/Nav2 时才会读取对应的 YAML。YAML 中引用的是同目录下的相对 PGM 文件，因此迁移后请让每一对 `.yaml` 和 `.pgm` 始终放在一起。

## 还需要打包什么

对当前四个静态场景，这个包已经够用。若还希望在新电脑中生成 Yahboom 小车并运行雷达、控制器、SLAM 或导航，还要另行迁移并编译机器人相关 ROS 包，包括 URDF/Xacro、meshes、launch、config、Gazebo/ROS 插件及其系统依赖。机器人并没有嵌入这四个 world 文件中。

## 兼容性提示

- `.world` 使用 SDF 1.6/1.7，面向 Gazebo Classic。
- 新版 Gazebo Sim（命令通常是 `gz sim`）与 Gazebo Classic 并不完全等价；如需迁移到新版，可能需要转换或调整材质/物理参数。
- 在另一台电脑上，Gazebo 与 ROS 版本最好和原电脑一致，可减少插件和消息接口兼容问题。
